# 🏠 Multimodal Housing Price Prediction – Flask App

## 📌 Objective
The objective of this project is to build a **multimodal machine learning system** that accurately predicts house prices by combining:

- **Structured tabular data** (e.g., area, number of rooms)
- **Unstructured image data** (photos of houses)

This system is deployed as a **Flask web application** where users can input house features and upload an image to get an instant price prediction.

---

## ⚙️ Methodology / Approach

### 🔹 Dataset Used
- **Source**: [Kaggle – House Prices and Images SoCal Dataset](https://www.kaggle.com/datasets/ted8080/house-prices-and-images-socal)
- **Components**:
  - `socal2.csv`: Contains tabular data (area, number of rooms, price, image filename)
  - `images/`: Folder of house images

---

### 🔹 Workflow

#### 1. **Image Feature Extraction**
- A pre-trained **ResNet50** Convolutional Neural Network (CNN) was used to extract image embeddings (without fine-tuning).
- Each house image was resized and passed through the CNN to obtain a fixed-size feature vector.

#### 2. **Tabular Data Processing**
- Features like `area` and `rooms` were standardized using `StandardScaler`.

#### 3. **Feature Fusion**
- The image features and scaled tabular data were **concatenated into a single vector** for each house.
- This hybrid vector was used to train a regression model.

#### 4. **Model Training**
- A **Random Forest Regressor** was trained on the combined feature vectors.
- The model was saved as `model.pkl`, and the scaler as `scaler.pkl`.

#### 5. **Web Deployment (Flask)**
- Users interact via a simple HTML form.
- Input: area, number of rooms, image of house
- Output: predicted price displayed on screen

---

## 📊 Key Results / Observations

| Metric | Value |
|--------|-------|
| Mean Absolute Error (MAE) | ~35,000 USD |
| Root Mean Squared Error (RMSE) | ~49,000 USD |

### 🧠 Observations
- Combining CNN image features with tabular data significantly improves model accuracy over using tabular data alone.
- Pre-trained CNNs like ResNet50 are effective even without fine-tuning on small datasets.
- Flask provides an intuitive and lightweight interface for real-time price prediction.

---

## 🚀 Run the App Locally
python app.py
